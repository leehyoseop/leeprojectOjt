package com.example.demo.employee.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeptOrganizationDTO {
	private String deptId;
	private String updeptId;
	private String deptNm;
	private String empList;
}
