package com.example.demo.employee.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DepartmentDTO {
	private String deptId;
	private String deptNm;
	private String upDeptId;
}
