package com.example.demo.employee.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HobbyDTO {
	private String hobId;
	private String hobNm;
	//private List<String> hobbies;
}
